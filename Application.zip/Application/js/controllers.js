angular.module('starter.controllers', [])

.controller('DashCtrl', function($scope) {})

.controller('LoginCtrl', function($scope, $state, $ionicPopup, $location, $ionicModal, $ionicLoading, $rootScope) {
  $ionicModal.fromTemplateUrl('templates/signup.html', {
    scope: $scope,
    animation: 'slide-in-up'
  }).then(function(modal){
    $scope.modal = modal;
  });

  $scope.logIn = function(user){
    if (user && user.email && user.pwdForLogin) {
      $ionicLoading.show({template: 'Signing in...'});

      firebase.auth().signInWithEmailAndPassword(user.email, user.pwdForLogin).catch(function(error){
        var errorMessage = error.message;
        var errorCode = error.code;

        if (error) {
          $ionicLoading.hide();
          $ionicPopup.alert({
            template: errorMessage,
            title: 'LOGIN FAILED',
            buttons: [{
              type: 'button-assertive',
              text: '<b>Ok</b>'
            }]
          });
          user.email = '';
          user.pwdForLogin = '';
        }

      });
    } else {
      $ionicLoading.hide();
      $ionicPopup.alert({
        template: 'Please Check Credentials.',
        title: 'LOGIN FAILED',
        buttons: [{
          type: 'button-assertive',
          text: '<b>Ok<b>'
        }]
      });
    }
  }

  $scope.signUp = function(user){
    if (user && user.email && user.password) {
      $ionicLoading.show({template: 'Creating account...'});
      $scope.modal.hide();

      firebase.auth().createUserWithEmailAndPassword(user.email, user.password).catch(function(error){
        var errorCode = error.code;
        var errorMessage = error.message;

        if (error) {
          $ionicLoading.hide();

          $ionicPopup.alert({
            template: errorMessage,
            title: 'REGISTRATION FAILED',
            buttons: [{
              type: 'button-assertive',
              text: '<b>Ok</b>'
            }]
          });

          user.email = '';
          user.password = '';
        }

      });
    }
  }
})

.controller('ChatsCtrl', function($scope, Chats) {
  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  $scope.chats = Chats.all();
  $scope.remove = function(chat) {
    Chats.remove(chat);
  };
})

.controller('ChatDetailCtrl', function($scope, $stateParams, Chats) {
  $scope.chat = Chats.get($stateParams.chatId);
})

.controller('AccountCtrl', function($scope) {
  $scope.logOut = function(){
    firebase.auth().signOut();
  }
});

const fs = require('fs');
const path = require('path');
const express = require('express');
const csv = require('csv-parser');
const bodyparser = require('body-parser');

const app = express();
const port = 3000;

const { Client } = require('whatsapp-web.js');

const SESSION_FILE_PATH = path.join(__dirname,'session.json');
var inputFilePath = path.join(__dirname,'data.csv');

let sessionCfg;
if (fs.existsSync(SESSION_FILE_PATH)) {
    sessionCfg = require(SESSION_FILE_PATH);
}

const client = new Client({ puppeteer: { headless: false }, session: sessionCfg });
// You can use an existing session and avoid scanning a QR code by adding a "session" object to the client options.
// This object must include WABrowserId, WASecretBundle, WAToken1 and WAToken2.

// You also could connect to an existing instance of a browser
// { 
//    puppeteer: {
//        browserWSEndpoint: `ws://localhost:3000`
//    }
// }

client.initialize();

client.on('qr', (qr) => {
    // NOTE: This event will not be fired if a session is specified.
    console.log('QR RECEIVED', qr);
});

client.on('authenticated', (session) => {
    console.log('AUTHENTICATED', session);
    sessionCfg=session;
    fs.writeFile(SESSION_FILE_PATH, JSON.stringify(session), function (err) {
        if (err) {
            console.error(err);
        }
    });
}); 

client.on('auth_failure', msg => {
    // Fired if session restore was unsuccessfull
    console.error('AUTHENTICATION FAILURE', msg);
});

client.on('ready', () => {
    console.log('READY');
});

client.on('message', async msg => {
    console.log('MESSAGE RECEIVED', msg);
    console.log('Message from - ', msg.from);
    // client.sendMessage(msg.from, 'I am not Vishal, I am a bot!! Just a test');
});

app.use(express.static('public'));

// parse application/x-www-form-urlencoded
app.use(bodyparser.urlencoded({ extended: false }))

// parse application/json
app.use(bodyparser.json())

app.post('/', (req, res) => {
    console.log(req.body);

    inputFilePath = req.body.filepath;

    fs.createReadStream(inputFilePath)
    .pipe(csv())
    .on('data', function(data){
        try {
            console.log("number is: "+data.number);
            console.log("message is: "+req.body.message);

            //perform the operation
            client.sendMessage('91'+data.number+'@c.us',req.body.message);
        }
        catch(err) {
            //error handler
            res.send('Send Failed ' + err.message);
        }
    })
    .on('end',function(){
        //some final operation
    });  

    // client.sendMessage('91'+'9488909128'+'@c.us', 'Hi Manju!!! This message coming from my app.. ');
    res.send('Sent Successfully!!')
})

app.listen(port, () => {
    console.log('Server up and running')
});
// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.services' is found in services.js
// 'starter.controllers' is found in controllers.js

document.addEventListener('deviceready', function () {
  // Enable to debug issues.
  // window.plugins.OneSignal.setLogLevel({logLevel: 4, visualLevel: 4});
  
  var notificationOpenedCallback = function(jsonData) {
    console.log('didReceiveRemoteNotificationCallBack: ' + JSON.stringify(jsonData));
  };

  window.plugins.OneSignal.init("724ed0e2-265d-4231-96ff-0f8f071341d8",
                                 {googleProjectNumber: "206199672122"},
                                 notificationOpenedCallback);
  
  // Show an alert box if a notification comes in when the user is in your app.
  window.plugins.OneSignal.enableInAppAlertNotification(true);
}, false);


angular.module('app', ['ionic', 'app.controllers', 'app.routes', 'app.services', 'app.directives'])

.run(function($ionicPlatform, $ionicLoading, $ionicModal, $rootScope, $ionicPopup, $location) {
  $ionicPlatform.ready(function() {
	  
	  if(navigator && navigator.splashscreen)
		  navigator.splashscreen.hide();
	  
	 //Checking for internet connection
	/*  if(window.Connection) {
          if(navigator.connection.type == Connection.NONE) {
              $ionicPopup.confirm({
                  title: "Internet Disconnected",
                  content: "No Internet Connection Available"
              })
              .then(function(result) {
                  if(!result) {
                      ionic.Platform.exitApp();
                  }
              });
          }
      } */
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);
    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }
  });
  
  firebase.auth().onAuthStateChanged(function(user){
	    if (user) {
	    	$rootScope.userEmail = user.email;
	    	$rootScope.userName = user.displayName;
	    	var userNameString = user.email.split("@");
			var str2 = userNameString[0].replace(/\./g,"")
		     var playersRef = firebase.database().ref("registerDetails/"+str2);
			playersRef.once('value').then(function(snapshot) {
			  $rootScope.company = snapshot.val().data.company;
			  $rootScope.tin = snapshot.val().data.tin;
			  $rootScope.telNumber = snapshot.val().data.mobile;
			  $rootScope.companyAddress = snapshot.val().data.companyAddress;
			  $rootScope.type = snapshot.val().data.type;
			  $rootScope.streetAddress = snapshot.val().data.streetAddress;
			  $rootScope.streetAddress1 = snapshot.val().data.streetAddress1;
			  $rootScope.city = snapshot.val().data.city;
			  $rootScope.state = snapshot.val().data.state;
			  $rootScope.pincode = snapshot.val().data.pincode;
			  $rootScope.country = snapshot.val().data.country;
			  console.log(snapshot.val().data);
			});
	      $ionicLoading.hide();
	      $location.path('/page1/page5');
	    } else {
	      $ionicLoading.hide();
	      $location.path('/page21');
	    }
	  });

	  var user = firebase.auth().currentUser;

	  if (user) {
		  $rootScope.userEmail = user.email;
		  $rootScope.userName = user.displayName;
		
		  console.log(user);
	    $location.path('/page1/page5');
	  } else {
	    $location.path('/page21')
	  }
})
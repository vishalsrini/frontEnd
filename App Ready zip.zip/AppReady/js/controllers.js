angular.module('app.controllers', [])
        
.controller('apaarrSchedulerCtrl', function($scope, $ionicSideMenuDelegate, $ionicModal, $ionicHistory) {
	$ionicHistory.clearHistory();
	$ionicSideMenuDelegate.canDragContent(true);
	$ionicModal.fromTemplateUrl('templates/processFlow.html', {
	    scope: $scope,
	    animation: 'slide-in-up'
	  }).then(function(modal){
	    $scope.modal = modal;
	  });
})
   
.controller('viewCtrl', function($scope) {

})
   
.controller('rawCashewCtrl', function($scope) {

})
   
.controller('processedCashewCtrl', function($scope) {

})
   
.controller('rawCashewBuyerSchedulerCtrl', function($scope) {

})
   
.controller('processedCashewBuyerSchedulerCtrl', function($scope) {

})
   
.controller('processedCashewSellerSchedulerCtrl', function($scope) {

})
   
.controller('rawCashewSellerSchedulerCtrl', function($scope) {

})
   
.controller('contactUsCtrl', function($scope, $ionicPopup, $ionicSideMenuDelegate, $ionicHistory) {
	$ionicSideMenuDelegate.canDragContent(true);
	var user = firebase.auth().currentUser;
	$scope.update = function(uname) {
		user.updateProfile({
			  displayName: uname
			}).then(function() {
			  // Update successful.
				$ionicPopup.alert({
		            template: 'Successfull updation of username',
		            title: 'UPDATED SUCCESSFULLY',
		            buttons: [{
		              type: 'button-dark',
		              text: '<b>Ok</b>'
		            }]
		          });
			}, function(error) {
			  // An error happened.
			});
	}
	
	$scope.logOut = function(){
		$ionicHistory.clearHistory();
		$ionicHistory.nextViewOptions({
	        disableBack: true
	    });
	    firebase.auth().signOut();
	  }
	
})
   
.controller('rawCashewViewerCtrl', function($scope) {
})
   
.controller('processedCashewViewerCtrl', function($scope) {
})
   
.controller('loginCtrl', function($scope, $state, $ionicPopup, $location, $ionicModal, $ionicLoading, $rootScope, $ionicHistory, $ionicSideMenuDelegate) {
	$ionicHistory.clearHistory();
	$ionicSideMenuDelegate.canDragContent(false);
		  $ionicModal.fromTemplateUrl('templates/signup.html', {
		    scope: $scope,
		    animation: 'slide-in-up'
		  }).then(function(modal){
		    $scope.modal = modal;
		  });

		  $scope.logIn = function(user){
		    if (user && user.email && user.pwdForLogin) {
		      $ionicLoading.show({template: 'Signing in...'});

		      $ionicHistory.nextViewOptions({
		            disableBack: true
		        });
		      firebase.auth().signInWithEmailAndPassword(user.email, user.pwdForLogin).catch(function(error){
		        var errorMessage = error.message;
		        var errorCode = error.code;

		        if (error) {
		          $ionicLoading.hide();
		          $ionicPopup.alert({
		            template: errorMessage,
		            title: 'LOGIN FAILED',
		            buttons: [{
		              type: 'button-assertive',
		              text: '<b>Ok</b>'
		            }]
		          });
		          user.email = '';
		          user.pwdForLogin = '';
		        }

		      });
		    } else {
		      $ionicLoading.hide();
		      $ionicPopup.alert({
		        template: 'Please Check Credentials.',
		        title: 'LOGIN FAILED',
		        buttons: [{
		          type: 'button-assertive',
		          text: '<b>Ok<b>'
		        }]
		      });
		    }
		  }

		  $scope.signUp = function(user){
		    if (user && user.email && user.password) {
		      $ionicLoading.show({template: 'Creating account...'});
		      $scope.modal.hide();

		      firebase.auth().createUserWithEmailAndPassword(user.email, user.password).catch(function(error){
		        var errorCode = error.code;
		        var errorMessage = error.message;

		        if (error) {
		          $ionicLoading.hide();

		          $ionicPopup.alert({
		            template: errorMessage,
		            title: 'REGISTRATION FAILED',
		            buttons: [{
		              type: 'button-assertive',
		              text: '<b>Ok</b>'
		            }]
		          });

		          user.email = '';
		          user.password = '';
		        }

		      });
		      
		      
		    }
		  }
		})
   
.controller('signupCtrl', function($scope) {

})
 
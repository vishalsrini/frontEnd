 angular.module('helloworld', [])
  .controller('myController', function($scope) {
     var Person=
	 {
	 firstName:'Jayanthi',
	 lastName:'Ramasubramanian',
	 };
	 $scope.person= Person;
    })	;
 
   
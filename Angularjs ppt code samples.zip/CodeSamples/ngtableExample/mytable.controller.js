//Demo of Searching and Sorting Table with AngularJS
var myApp = angular.module('myApp', ["ngTable"]);

myApp.controller('TableCtrl', ['$scope','NgTableParams', function ($scope,NgTableParams) {
	var data =getDummyData();
	this.tableParams = new NgTableParams({}, { dataset: data});
    }]);
/*Get Dummy Data for Example*/
function getDummyData() {
    return [{
        EmpId: 2,
        name: 'Jitendra',
        Email: 'jz@gmail.com'
    }, {
        EmpId: 1,
        name: 'Minal',
        Email: 'amz@gmail.com'
    }, {
        EmpId: 3,
        name: 'Rudra',
        Email: 'ruz@gmail.com'
    }];
}
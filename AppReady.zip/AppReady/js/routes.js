angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('tabsController.apaarrScheduler', {
    url: '/page5',
    views: {
      'tab3': {
        templateUrl: 'templates/apaarrScheduler.html',
        controller: 'apaarrSchedulerCtrl'
      }
    }
  })

  .state('tabsController.view', {
    url: '/page14',
    views: {
      'tab3': {
        templateUrl: 'templates/view.html',
        controller: 'viewCtrl'
      }
    }
  })

  .state('tabsController.rawCashew', {
    url: '/page12',
    views: {
      'tab3': {
        templateUrl: 'templates/rawCashew.html',
        controller: 'rawCashewCtrl'
      }
    }
  })

  .state('tabsController.processedCashew', {
    url: '/page13',
    views: {
      'tab3': {
        templateUrl: 'templates/processedCashew.html',
        controller: 'processedCashewCtrl'
      }
    }
  })

  .state('tabsController.rawCashewBuyerScheduler', {
    url: '/page17',
    views: {
      'tab3': {
        templateUrl: 'templates/rawCashewBuyerScheduler.html',
        controller: 'rawCashewBuyerSchedulerCtrl'
      }
    }
  })

  .state('tabsController.processedCashewBuyerScheduler', {
    url: '/page19',
    views: {
      'tab3': {
        templateUrl: 'templates/processedCashewBuyerScheduler.html',
        controller: 'processedCashewBuyerSchedulerCtrl'
      }
    }
  })

  .state('tabsController.processedCashewSellerScheduler', {
    url: '/page20',
    views: {
      'tab3': {
        templateUrl: 'templates/processedCashewSellerScheduler.html',
        controller: 'processedCashewSellerSchedulerCtrl'
      }
    }
  })

  .state('tabsController.rawCashewSellerScheduler', {
    url: '/page18',
    views: {
      'tab3': {
        templateUrl: 'templates/rawCashewSellerScheduler.html',
        controller: 'rawCashewSellerSchedulerCtrl'
      }
    }
  })

  .state('tabsController.contactUs', {
    url: '/page8',
    views: {
      'tab8': {
        templateUrl: 'templates/contactUs.html',
        controller: 'contactUsCtrl'
      }
    }
  })

  .state('tabsController.rawCashewViewer', {
    url: '/page15',
    views: {
      'tab3': {
        templateUrl: 'templates/rawCashewViewer.html',
        controller: 'rawCashewViewerCtrl'
      }
    }
  })

  .state('tabsController.processedCashewViewer', {
    url: '/page16',
    views: {
      'tab3': {
        templateUrl: 'templates/processedCashewViewer.html',
        controller: 'processedCashewViewerCtrl'
      }
    }
  })

  .state('login', {
    url: '/page21',
    templateUrl: 'templates/login.html',
    controller: 'loginCtrl'
  })


$urlRouterProvider.otherwise('/page21')

  

});
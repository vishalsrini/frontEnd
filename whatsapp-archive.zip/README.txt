First time Run
1. Download nodejs from nodejs.org website. Download LTS version. Latest LTS version - 16.13.0
https://nodejs.org/en/

2. Extract the attached code in following directory C:/data/whatsapp [ Make sure index.js is present in C:/data/whatsapp directory ]
3. Copy whatsapp-bot.bat in your desktop or somewhere because that is the trigger to start whatsapp web.
4. Double click on whatsapp-bot.bat and you will be good to go.
[ First time it will take some time since it will install dependencies in your machine. ]

Subsequent Runs
Double click whatsapp-bot.bat

open chrome or any browser and go to http://localhost:3000

